import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const CalculadoraApp());
}

class CalculadoraApp extends StatelessWidget {
  const CalculadoraApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Calculadora Flutter',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        brightness: Brightness.dark, // Tema oscuro para darle buen aspecto
      ),
      home: const PantallaCalculadora(),
    );
  }
}

class PantallaCalculadora extends StatefulWidget {
  const PantallaCalculadora({Key? key}) : super(key: key);

  @override
  State<PantallaCalculadora> createState() => _PantallaCalculadoraState();
}

class _PantallaCalculadoraState extends State<PantallaCalculadora> {
  String _salida = "0";
  String _numeroActual = "";
  double _num1 = 0;
  double _num2 = 0;
  String _operador = "";

  void _presionarBoton(String textoBoton) {
    setState(() {
      if (textoBoton == "C") {
        // Limpiar todo
        _salida = "0";
        _numeroActual = "";
        _num1 = 0;
        _num2 = 0;
        _operador = "";
      } else if (textoBoton == "√") {
        // Raíz cuadrada (calcula inmediatamente sobre el número actual)
        _num1 = double.tryParse(_salida) ?? 0;
        if (_num1 >= 0) {
          _salida = _formatearSalida(sqrt(_num1));
          _numeroActual = _salida;
        } else {
          _salida = "Error"; // No hay raíces reales de números negativos
        }
      } else if (textoBoton == "+" ||
          textoBoton == "-" ||
          textoBoton == "*" ||
          textoBoton == "/" ||
          textoBoton == "^") {
        // Operadores de dos pasos
        _num1 = double.tryParse(_salida) ?? 0;
        _operador = textoBoton;
        _numeroActual = "";
      } else if (textoBoton == "=") {
        // Ejecutar operación
        _num2 = double.tryParse(_numeroActual) ?? 0;

        switch (_operador) {
          case "+":
            _salida = _formatearSalida(_num1 + _num2);
            break;
          case "-":
            _salida = _formatearSalida(_num1 - _num2);
            break;
          case "*":
            _salida = _formatearSalida(_num1 * _num2);
            break;
          case "/":
            _salida = _num2 == 0 ? "Error" : _formatearSalida(_num1 / _num2);
            break;
          case "^":
            _salida = _formatearSalida(pow(_num1, _num2).toDouble());
            break;
        }
        _operador = "";
        _numeroActual = _salida;
      } else {
        // Concatenar números y decimales
        if (textoBoton == "." && _numeroActual.contains(".")) {
          return; // Evitar múltiples puntos decimales
        }
        _numeroActual += textoBoton;
        _salida = _numeroActual;
      }
    });
  }

  // Método para quitar los ".0" innecesarios si es un número entero
  String _formatearSalida(double resultado) {
    String res = resultado.toString();
    if (res.endsWith(".0")) {
      return res.substring(0, res.length - 2);
    }
    return res;
  }

  Widget _construirBoton(String texto, {Color? colorTexto, Color? colorFondo}) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: colorFondo ?? Colors.grey[800],
              padding: const EdgeInsets.all(22.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              )
          ),
          onPressed: () => _presionarBoton(texto),
          child: Text(
            texto,
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: colorTexto ?? Colors.white
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Calculadora"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Pantalla de la calculadora
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
              child: Text(
                _salida,
                style: const TextStyle(fontSize: 60, fontWeight: FontWeight.bold),
                maxLines: 1,
              ),
            ),
          ),
          const Divider(height: 1, color: Colors.grey),
          // Teclado
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  children: [
                    _construirBoton("C", colorTexto: Colors.redAccent),
                    _construirBoton("√", colorTexto: Colors.cyan),
                    _construirBoton("^", colorTexto: Colors.cyan),
                    _construirBoton("/", colorTexto: Colors.cyan),
                  ],
                ),
                Row(
                  children: [
                    _construirBoton("7"),
                    _construirBoton("8"),
                    _construirBoton("9"),
                    _construirBoton("*", colorTexto: Colors.cyan),
                  ],
                ),
                Row(
                  children: [
                    _construirBoton("4"),
                    _construirBoton("5"),
                    _construirBoton("6"),
                    _construirBoton("-", colorTexto: Colors.cyan),
                  ],
                ),
                Row(
                  children: [
                    _construirBoton("1"),
                    _construirBoton("2"),
                    _construirBoton("3"),
                    _construirBoton("+", colorTexto: Colors.cyan),
                  ],
                ),
                Row(
                  children: [
                    _construirBoton("."),
                    _construirBoton("0"),
                    _construirBoton("=", colorFondo: Colors.cyan, colorTexto: Colors.black),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}